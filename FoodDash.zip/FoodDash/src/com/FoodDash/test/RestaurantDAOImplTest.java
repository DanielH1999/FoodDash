package com.FoodDash.test;

import com.FoodDash.dao.RestaurantDAOImpl;

public class RestaurantDAOImplTest {
    
    public static void main(String[] args) {
        RestaurantDAOImpl rdao = new RestaurantDAOImpl();
        
        rdao.aceptar_pedido();
    }
}
