package com.FoodDash.entities;


public class Cliente {
    
}
