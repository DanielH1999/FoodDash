package com.FoodDash.dao;

public class EnvioDAOImpl
{
    
}
